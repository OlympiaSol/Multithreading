#include <string.h>
#include "../engine/db.h"
#include "../engine/variant.h"
#include "bench.h"


//arikopoihsh mutex gia ton ypologismo tou kostous write kai read kai gia to found
pthread_mutex_t write_cost_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t read_cost_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t found_mutex = PTHREAD_MUTEX_INITIALIZER;

//synoliko kostos read kai write
double total_read_cost = 0.0; 
double total_write_cost = 0.0; 
int found = 0; //metavlhth gia thn katametrhsh twn keys pou exoun vrethei


//ektypwsh statistikwn gia to write
void print_statistcs_write(long int count){
	
	printf(LINE);
		printf("|Random-Write	(done:%ld): %.6f sec/op; %.1f writes/sec(estimated); cost:%.3f(sec);\n"
		,count, (double)(total_write_cost / count)
		,(double)(count / total_write_cost)
		,total_write_cost);
		
	return;
}

//ektypwsh statistikwn gia to read
void print_statistcs_read(long int count){
	
	printf(LINE);
		printf("|Random-Read	(done:%ld, found:%d): %.6f sec/op; %.1f reads /sec(estimated); cost:%.3f(sec)\n",
		count, found,
		(double)(total_read_cost / count),
		(double)(count / total_read_cost),
		total_read_cost);

	return;
}

//ypologizei to start
long long metrhsh_start() {
    return get_ustime_sec();
}

//ypologizei to kostos(cost)
double ypologismos_kostous(long long start) {
    long long end = get_ustime_sec();
    return (double)(end - start);
}

//ypologismos synolikou kostous (total_cost)
void update_total_cost(pthread_mutex_t *mutex, double *total_cost, double cost) {
    pthread_mutex_lock(mutex);
    *total_cost += cost;
    pthread_mutex_unlock(mutex);
}

//dokimh gia to write
void *_write_test(struct orisma *write_arg){
	
	int i;
	double cost;
	long long start = metrhsh_start();
	Variant sk, sv;

	long int count= write_arg->count;
	int r = write_arg->r;
	DB* db = write_arg->db;
	
	char key[KSIZE + 1];
	char val[VSIZE + 1];
	char sbuf[1024];

	memset(key, 0, KSIZE + 1);
	memset(val, 0, VSIZE + 1);
	memset(sbuf, 0, 1024);

	for (i = 0; i < count; i++) {
		if (r)
			_random_key(key, KSIZE);
		else
			snprintf(key, KSIZE, "key-%d", i);
		fprintf(stderr, "%d adding %s\n", i, key);
		snprintf(val, VSIZE, "val-%d", i);

		sk.length = KSIZE;
		sk.mem = key;
		sv.length = VSIZE;
		sv.mem = val;

		db_add(db, &sk, &sv);
		if ((i % 10000) == 0) {
			fprintf(stderr,"random write finished %d ops%30s\r",
					i,
					"");
			fflush(stderr);
		}
	}

	cost = ypologismos_kostous(start);
    update_total_cost(&write_cost_mutex, &total_write_cost, cost);

	return NULL;
}

//dokimh gia to read
void *_read_test(struct orisma *read_arg){
	
	int i;
	int ret;
	double cost;
	long long start = metrhsh_start();
	Variant sk;
	Variant sv;
	char key[KSIZE + 1];

	long int count= read_arg->count;
	int r = read_arg->r;
	DB* db= read_arg->db;

	for (i = 0; i < count; i++) {
		memset(key, 0, KSIZE + 1);

		if (r)
			_random_key(key, KSIZE);
		else
			snprintf(key, KSIZE, "key-%d", i);
		fprintf(stderr, "%d searching %s\n", i, key);
		sk.length = KSIZE;
		sk.mem = key;
		ret = db_get(db, &sk, &sv);
		if (ret) {
			pthread_mutex_lock(&found_mutex);
			found++;
			pthread_mutex_unlock(&found_mutex);
		} else {
			INFO("not found key#%s",
					sk.mem);
    	}

		if ((i % 10000) == 0) {
			fprintf(stderr,"random read finished %d ops%30s\r",
					i,
					"");
			fflush(stderr);
		}
	}

	cost = ypologismos_kostous(start);
    update_total_cost(&read_cost_mutex, &total_read_cost, cost);

	return NULL;

}

