#include "bench.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../engine/db.h"

#define DATAS ("testdb")

void _random_key(char *key,int length) {
	
	int i;
	char salt[36]= "abcdefghijklmnopqrstuvwxyz0123456789";

	for (i = 0; i < length; i++)
		key[i] = salt[rand() % 36];
}

void _print_header(int count){
	
	double index_size = (double)((double)(KSIZE + 8 + 1) * count) / 1048576.0;
	double data_size = (double)((double)(VSIZE + 4) * count) / 1048576.0;

	printf("Keys:\t\t%d bytes each\n",
			KSIZE);
	printf("Values: \t%d bytes each\n",
			VSIZE);
	printf("Entries:\t%d\n",
			count);
	printf("IndexSize:\t%.1f MB (estimated)\n",
			index_size);
	printf("DataSize:\t%.1f MB (estimated)\n",
			data_size);

	printf(LINE1);
}

void _print_environment(){
	
	time_t now = time(NULL);

	printf("Date:\t\t%s",
			(char*)ctime(&now));

	int num_cpus = 0;
	char cpu_type[256] = {0};
	char cache_size[256] = {0};

	FILE* cpuinfo = fopen("/proc/cpuinfo", "r");
	if (cpuinfo) {
		char line[1024] = {0};
		while (fgets(line, sizeof(line), cpuinfo) != NULL) {
			const char* sep = strchr(line, ':');
			if (sep == NULL || strlen(sep) < 10)
				continue;

			char key[1024] = {0};
			char val[1024] = {0};
			strncpy(key, line, sep-1-line);
			strncpy(val, sep+1, strlen(sep)-1);
			if (strcmp("model name", key) == 0) {
				num_cpus++;
				strcpy(cpu_type, val);
			}
			else if (strcmp("cache size", key) == 0)
				strncpy(cache_size, val + 1, strlen(val) - 1);
		}

		fclose(cpuinfo);
		printf("CPU:\t\t%d * %s",
				num_cpus,
				cpu_type);

		printf("CPUCache:\t%s\n",
				cache_size);
	}
}

//anoigei th vash dedomenwn
void anoigma_db(DB **db) {
    *db = db_open(DATAS);
}

//pairnei ta orismata apo to xrhsth kai kanei elegxo
void orismata_apo_xrhsth(int argc, char** argv, long int* count) {
	
    if (argc < 3) {
        fprintf(stderr,"Usage: db-bench <write | read > <count> or db-bench <readwrite> <count> <pososto_readentage> <pososto_writeentage>\n");
        exit(1);
    }
    *count = atoi(argv[2]);
}

//dhmiourgei nhmata
void create_threads(pthread_t* thread_id, int threads, void* (*synarthsh)(void*), struct orisma* arg) {
	
    for(int i = 0; i < threads; i++) {
        pthread_create(&thread_id[i], NULL, synarthsh, (void*)arg);
    }
}

//perimenei na oloklhrwthoun ola ta nhmata
void join_thread(pthread_t* thread_id, int threads) {
	
    for(int i = 0; i < threads; i++) {
        pthread_join(thread_id[i], NULL);
    }
}

int main(int argc,char** argv) {
	
    DB* db = NULL;
	
    long int count;
    
    orismata_apo_xrhsth(argc, argv, &count); //analysh orismatwn xrhsth
	
	void *_write_test(void *arg); 
	void *_read_test(void *arg); 
	
    int threads = 0; //nimata
    pthread_t* thread_id;

    struct orisma arg;
	
    srand(time(NULL));  //gennhtria tyxaiwn arithmwn
    
	//leitourgies read kai write
    if (strcmp(argv[1], "write") == 0 || strcmp(argv[1], "read") == 0) {
		
		int r = 0; //flag gia tyxaia dhmiourgia kleidiou
		
        printf("Give number of threads: ");
        scanf("%d", &threads);
		
        thread_id = (pthread_t*) malloc(threads * sizeof(pthread_t));
		_print_header(count);
		_print_environment();
        if (argc == 4)
			r = 1;
		
		anoigma_db(&db);
		
		arg.count = count / threads;  //katanomh twn leitourgiwn sta nhmata
		arg.r = r;
		arg.db = db;
		
        if (strcmp(argv[1], "write") == 0) {
            create_threads(thread_id, threads, _write_test, &arg); 
            join_thread(thread_id, threads);
			
			db_close(db);
			
            print_statistcs_write(count);  //ektypwsh statistikwn leitourgias write
        }
		else if (strcmp(argv[1], "read") == 0) {
            create_threads(thread_id, threads, _read_test, &arg);
            join_thread(thread_id, threads);
			
			db_close(db);
			
            print_statistcs_read(count);  //ektypwsh statistikwn leitourgias read
        }
    } 
	
	//leitourgia readwrite
	else if (strcmp(argv[1], "readwrite") == 0) {
		
		int r = 0;
		int pososto_read = atoi(argv[3]);
		int pososto_write = atoi(argv[4]);
		int threads_read =0; //nimata gia reading
		printf("Give number of threads for reading: ");
		scanf("%d", &threads_read);
		
		int threads_write =0; //nimata gia writing
		printf("Give number of threads for writing: ");
		scanf("%d", &threads_write);
		
		_print_header(count);
		_print_environment();
		
		pthread_t *read_thread_id, *write_thread_id;

		if (argc == 4)
			r = 1;
		
		anoigma_db(&db);
		
		//dhmiourgia struct gia orismata tou read_test ka tou write_test
		struct orisma read_arg;
		read_arg.r = r;
		read_arg.db = db;
		struct orisma write_arg;
		write_arg.r = r;
		write_arg.db = db;

		read_thread_id = (pthread_t*) malloc(threads_read * sizeof(pthread_t));
		write_thread_id = (pthread_t*) malloc(threads_write * sizeof(pthread_t));

		//arxikopoihsh orismatwn gia leitourgies read-write
		read_arg.count = (count * pososto_read) / (100 * threads_read);
		write_arg.count = (count * pososto_write) / (100 * threads_write);
		
		//dhmiourgia threads gia read-write
		create_threads(read_thread_id, threads_read, _read_test, &read_arg);
		create_threads(write_thread_id, threads_write, _write_test, &write_arg);

		//wait mexri ola ta nhmata read-write na oloklhrwsoun ta tasks tous
		join_thread(read_thread_id, threads_read);
		join_thread(write_thread_id, threads_write);

		free(read_thread_id);
		free(write_thread_id);

		//ypologismos statistikwn read kai write
		long int synoliko_count_read = count * pososto_read / 100;
		long int synoliko_count_write = count * pososto_write / 100;
		
		db_close(db);
		
		//ektypwsh statistikwn leitourgias read kai write
		print_statistcs_read(synoliko_count_read);
		print_statistcs_write(synoliko_count_write);
	}
	else {
        fprintf(stderr,"Invalid operation specified. Usage: db-bench <write | read > <count> or db-bench <readwrite> <count> <pososto_readentage> <pososto_writeentage>\n");
        exit(1);
    }
    return 0;
}
